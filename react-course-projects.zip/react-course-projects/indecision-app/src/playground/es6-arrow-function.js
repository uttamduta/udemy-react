console.log('es6-arrow-function.js is running');

const square = function(x) {

    return x * x;

}

//const squareArrow = (x) => {
//    return x * x;
//}

const squareArrow = (x) => x * x;

console.log(square(10));

console.log(squareArrow(8));

const squareFirstName = ( strName) => strName.split(' ')[0];

console.log(squareFirstName('Ram krishna'));
