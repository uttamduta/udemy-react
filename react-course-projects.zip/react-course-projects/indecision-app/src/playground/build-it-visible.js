// Chapter 35 solution - completed on 12/03/2020

class VisibilityToggle extends React.Component{
    constructor(props) {
        super(props);
        this.handleToggleVisibility = this.handleToggleVisibility.bind(this);
        this.state ={
            visibilityFlag: false
        };
    }

    handleToggleVisibility (){
        this.setState((prevState) => {
            return {
                visibilityFlag: !prevState.visibilityFlag 
            };
        });           
    }
    
    render () {
        return ( 
            <div>
               <h1>Visibility Toggle</h1>
               <button onClick={this.handleToggleVisibility}>
                 {this.state.visibilityFlag ? 'Hide Details': 'Show details'}              
                </button>
                {this.state.visibilityFlag && (
                <div>
                    <p> Hey. These are some details you can now see !</p>
                </div>
                )}
            </div>    
        );
        }
    }
     
ReactDOM.render(<VisibilityToggle />,document.getElementById('app'));

// class Person  {

//     constructor(inpname = 'NoNameAnonymous') {
//         this.name = inpname;
//     }
//     getGreetings() {

//         return `Hi. I am ${this.name}`;
//     }
// }

// const me = new Person('Jai ram Krishna');
// console.log(me.getGreetings());

// const other = new Person();
// console.log(other.getGreetings());
