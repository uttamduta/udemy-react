class Person  {
    constructor(inpName = 'Anonymous',inpAge=0) {
        this.name = inpName;
        this.age  = inpAge;
    }
    getGreetings() {
        return `Hi. I am ${this.name}`;
    }
    getDescription(){
        return `${this.name} is ${this.age} year(s) old.`;
    }
}

class Student extends Person{

    constructor(inpName, inpAge, inpMajor) {
        super(inpName, inpAge);
        this.major = inpMajor;

    }

    hasMajor(){                 
        return !!this.major;
    }
 
    getDescription(){

        let description = super.getDescription();

        if (this.hasMajor()) {
            description += ` Their major is ${this.major}.`;
        }
        return description;
    }
}

class Traveller extends Person {
    constructor(inpName, inpAge, inpHomeLocation){
        super(inpName, inpAge)
        this.homeLocation = inpHomeLocation;
    }

getGreetings(){

    let greeting = super.getGreetings() ;
    
    if (this.homeLocation) {
        greeting += ` I am visting from ${this.homeLocation}`;
    }
    return greeting;
}

}


const me = new Traveller('Uttam Dutta',57,'Virginia');
//console.log(me.getDescription());
console.log(me.getGreetings());

const other = new Traveller(undefined,undefined,'No where');
//console.log(other.getDescription());
console.log(other.getGreetings());