// Exercizes on Chapter 28 

class IndecisionApp extends React.Component {
    render () {
        const title = 'Indecision';
        const subtitle = 'Put your life in hands of a Computer';
        const options = ['Thing one', 'Thing two', 'Thing four'];  
        return (
            <div>
               <Header title={title} subtitle={subtitle}/>
                <Action />
                <Options options={options}/>
                <AddOptions />
                </div> 
        )
    }
}

 class Header extends React.Component{
    render (){
        console.log('hello-Header');
        return (
            <div>
                <h1>{this.props.title}</h1>
                <h2>{this.props.subtitle}</h2>
            </div>
        );
    }
 }

 class Action extends React.Component{
    render (){
        console.log('hello-Action');
        return (
            <div>
                <button>What should I do ?</button>
            </div>
        );
    }
 }

 class Options extends React.Component {    
    render()

    {
        return ( 
            <div>
                {
                    
               //  this.props.options.map((option) => <p key={option}>{option}</p>) 
                this.props.options.map((option)=> <Option key={option} optionText={option}/>)
                }
            </div>
        );
    }
 }

class Option extends React.Component {
    render (){
        return( 
            <div>
                Option :{this.props.optionText}

            </div>
        );
    }
}

 class AddOptions extends React.Component {
    render(){
        return (
            <div>Adtions components here</div>
        );
    }
 }

 const jsx = (
         <IndecisionApp />
        
 );

 ReactDOM.render(<IndecisionApp />, document.getElementById('app'));