//  Solution for Chapter 44  : Life Cycle 
//  Ligfe Cycle methods can only can be accessd only from class based componenst
//  Method componentDidMount() : Called when a component gets mounted (loaded) and 
//  Method componentDidUpdate(): called when any props of the component gets updated    
//  Method componentDidUnount(): called when component gets deleted 
 
class IndecisionApp extends React.Component {
    constructor(props){
        super(props);
        this.handleDeleteOptions = this.handleDeleteOptions.bind(this);
        this.handlePick = this.handlePick.bind(this);
        this.handleAddOption = this.handleAddOption.bind(this);
        this.handleDeleteOption = this.handleDeleteOption.bind(this);

        this.state =  {
            options:props.options
 
        };
    }
    componentDidMount(){
        console.log('componentDidMount!');
    }
    componentDidUpdate(prevProps, prevState) {
        console.log('componentDidUpdate!');

    }
    componentWillUnmount(){
        console.log('componentWillUnMount!');
    }

 

    handleDeleteOptions() { 
        this.setState(()=> ({options:[]}));
    }

    handleDeleteOption(optionToRemove) {
        this.setState((prevState) =>  ({
            options: prevState.options.filter((option) => optionToRemove !== option )
        }));
     }
 
    handlePick(){
        const randomNum = Math.floor(Math.random() * this.state.options.length);
        const option = this.state.options[randomNum];
        alert(option);
    }

    handleAddOption (option){

        if (!option) {
          return 'Enter value to add item'
        } else if (this.state.options.indexOf(option) > -1) {
          return "This opion already exists"
        }

        this.setState((prevState) => ({
            options:prevState.options.concat(option)
        }));



    }
    render () {
        
        const subtitle = 'Put your life in hands of a Computer!';
        
        return (
            <div>
               <User name="Mrs. Sangeeta U. Dutta" age={50}/>
               <Header    subtitle={subtitle}/>
                <Action 
                  hasOptions ={this.state.options.length > 0}
                  handlePickFlag ={this.handlePick}
                />
                <Options
                  options={this.state.options}
                  handleDeleteOptionsFlag={this.handleDeleteOptions}
                  handleDeleteOption={this.handleDeleteOption}
                />
                <AddOptions 
                  handleAddOption={this.handleAddOption}               
                />
                </div> 
        )
    }
}

IndecisionApp.defaultProps = {

    options: []

};
 
const Header = (props) => {
    return (
        <div>
           <h1>{props.title}</h1>
           {props.title && <h2>{props.subtitle}</h2>}
        </div>
    );
}

Header.defaultProps = {
    title: 'Indecision Chapter44.'

}; 

// *** Header defined as a React Component per exersize 47 now commented as being replaced by stateless
// *** Function
//  class Header extends React.Component{
//     render (){
//         console.log('hello-Header');
//         return (
//             <div>
//                 <h1>{this.props.title}</h1>
//                 <h2>{this.props.subtitle}</h2>
//             </div>
//         );
//     }
//  }

const Action =(props) => {
    return (
        <div>
        <p>Action is called </p>
        
        <button 
           
           onClick={props.handlePickFlag}
           disabled={!props.hasOptions}
           >
           What should I do today?
        </button>
    </div>
        
    );
};

// *** Action defined as a React Component per exersize 47now commented as being replaced by stateless
// *** Function
// class Action extends React.Component{ 
//     render (){
//         console.log('hello-Action');
//         return (
             
//             <div>
//                 <button 
//                    onClick={this.props.handlePickFlag}
//                    disabled={!this.props.hasOptions}
//                    >
//                    What should I do?
//                 </button>
//             </div>
//         );
//     }
//  }


const Options = (props) => {

    return (
        <div>
        <button onClick={props.handleDeleteOptionsFlag}>Remove All</button>
        {              
          props.options.map((option)=> (   
            <Option 
                key={option} 
                optionText={option}
                handleDeleteOption={props.handleDeleteOption}
            />
            ))
        }
    </div>
    );
};


// *** Options defined as a React Component per exersize 47 now commented as being replaced by stateless
// *** Function
//  class Options extends React.Component {   
//     render()
//     {
//         return ( 
//             <div>
//                 <button onClick={this.props.handleDeleteOptionsFlag}>Remove All</button>
//                 {              
                 
//                   this.props.options.map((option)=> <Option key={option} optionText={option}/>)
//                 }
//             </div>
//         );
//     }
//  }


const Option = (props) => {
    return( 
        <div> 
            {props.optionText}
            <button 
                onClick={(e)=>{
                    props.handleDeleteOption(props.optionText);        
                }
               }    
            >
                Remove
            </button>
        </div>
    );

};

// *** Option defined as a React Component per exersize 47 now commented as being replaced by stateless
// *** Function
// class Option extends React.Component {
//     render (){
//         return( 
//             <div> 
//                 {this.props.optionText}

//             </div>
//         );
//     }
// }

class AddOptions extends React.Component {
    
    constructor(props){
        super(props);
        this.handleAddOption = this.handleAddOption.bind(this);
        this.state ={
            error: undefined
        };
    }

    handleAddOption(e){
        e.preventDefault();
        const option = e.target.elements.option.value.trim();
        const error  = this.props.handleAddOption(option);

        this.setState(()=> ({error}));
        
        }
         

    render(){
       
        return (
            
            <div>
                {this.state.error && <p>{this.state.error}</p>}
                <form onSubmit={this.handleAddOption}>
                    <input type="text" name="option"  />
                    <button>Add option</button>
                </form>
            </div>
        );
    }
 }

const User = (props) => {
    return  (
        <div>
            <h1>
                <p>Name : {props.name}</p>
                <p>Age : {props.age}</p>
            </h1>
        </div>

    );

;

}
ReactDOM.render(<IndecisionApp options={['Item 1','Item 2']}/>, document.getElementById('app'));