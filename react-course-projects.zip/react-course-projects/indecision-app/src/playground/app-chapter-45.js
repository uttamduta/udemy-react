//  Solution for Chapter 45  : Life Cycle 
  
class IndecisionApp extends React.Component {
    constructor(props){
        super(props);
        this.handleDeleteOptions = this.handleDeleteOptions.bind(this);
        this.handlePick = this.handlePick.bind(this);
        this.handleAddOption = this.handleAddOption.bind(this);
        this.handleDeleteOption = this.handleDeleteOption.bind(this);

        this.state =  {
            options:props.options
 
        };
    }

    componentDidMount(){

        try {
            const retrieveJSON = localStorage.getItem('myoptions');
            const retriveoptions = JSON.parse(retrieveJSON);
            if (retriveoptions){
                this.setState(() => ({options:retriveoptions}));
            }
        }
        catch(e){
            // Do Nothing at all
        }       
    }

    componentDidUpdate(prevProps, prevState) {
        
        if (prevState.options.length !==  this.state.options.length) {
            const json = JSON.stringify(this.state.options);
            localStorage.setItem('myoptions',json);
        }
    }

    componentWillUnmount(){
        console.log('componentWillUnMount!');
    }


    handleDeleteOptions() { 
        this.setState(()=> ({options:[]}));
    }

    handleDeleteOption(optionToRemove) {
        this.setState((prevState) =>  ({
            options: prevState.options.filter((option) => optionToRemove !== option )
        }));
     }
 
    handlePick(){
        const randomNum = Math.floor(Math.random() * this.state.options.length);
        const option = this.state.options[randomNum];
        alert(option);
    }

    handleAddOption (option){

        if (!option) {
          return 'Enter value to add item'
        } else if (this.state.options.indexOf(option) > -1) {
          return "This opion already exists"
        }

        this.setState((prevState) => ({
            options:prevState.options.concat(option)
        }));

        //  this.setState((prevState)=>{
        //     return {
        //         options:prevState.options.concat(option)
        //     };

        //  }
        //  );

    }
    render () {
        
        const subtitle = 'Put your life in hands of a Computer!';
        
        return (
            <div>
               <User name="Mrs. Sangeeta U. Dutta" age={50}/>
               <Header    subtitle={subtitle}/>
                <Action 
                  hasOptions ={this.state.options.length > 0}
                  handlePickFlag ={this.handlePick}
                />
                <Options
                  options={this.state.options}
                  handleDeleteOptionsFlag={this.handleDeleteOptions}
                  handleDeleteOption={this.handleDeleteOption}
                />
                <AddOptions 
                  handleAddOption={this.handleAddOption}               
                />
                </div> 
        )
    }
}

IndecisionApp.defaultProps = {

    options: []

};

const Header = (props) => {
    return (
        <div>
           <h1>{props.title}</h1>
           {props.title && <h2>{props.subtitle}</h2>}
        </div>
    );
}

Header.defaultProps = {
    title: 'Indecision Chapter-45.'

}; 



const Action =(props) => {
    return (
        <div>
        <p>Action is called </p>
        
        <button 
           
           onClick={props.handlePickFlag}
           disabled={!props.hasOptions}
           >
           What should I do today?
        </button>
    </div>
        
    );
};




const Options = (props) => {

    return (
        <div>
        <button onClick={props.handleDeleteOptionsFlag}>Remove All</button>
        {props.options.length === 0 && <p>Please add an option to get started</p>}
        {              
          props.options.map((option)=> (   
            <Option 
                key={option} 
                optionText={option}
                handleDeleteOption={props.handleDeleteOption}
            />
            ))
        }
    </div>
    );
};





const Option = (props) => {
    return( 
        <div> 
            {props.optionText}
            <button 
                onClick={(e)=>{
                    props.handleDeleteOption(props.optionText);        
                }
               }    
            >
                Remove
            </button>
        </div>
    );

};



class AddOptions extends React.Component {
    
    constructor(props){
        super(props);
        this.handleAddOption = this.handleAddOption.bind(this);
        this.state ={
            error: undefined
        };
    }

    handleAddOption(e){
        e.preventDefault();
        const option = e.target.elements.option.value.trim();
        const error  = this.props.handleAddOption(option);

        this.setState(()=> ({error}));
        if (!error){
            e.target.elements.option.value = '';  
        }
        }
         

    render(){
       
        return (
            
            <div>
                {this.state.error && <p>{this.state.error}</p>}
                <form onSubmit={this.handleAddOption}>
                    <input type="text" name="option"  />
                    <button>Add option</button>
                </form>
            </div>
        );
    }
 }

const User = (props) => {
    return  (
        <div>
            <h1>
                <p>Name : {props.name}</p>
                <p>Age : {props.age}</p>
            </h1>
        </div>

    );

;

}
ReactDOM.render(<IndecisionApp options={[]}/>, document.getElementById('app'));