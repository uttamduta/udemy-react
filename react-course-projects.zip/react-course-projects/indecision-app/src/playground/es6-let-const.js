var nameVar = 'HareKrishna';
nameVar = 'HareRam';
console.log('nameVar', nameVar);

let nameLet = 'Radhe';
nameLet = 'RadheKrishna';
console.log('nameLet',nameLet);

const nameConst = 'RakKrishna';
console.log('nameConst',nameConst);


// Block scoping

var fullName = 'Sangeeta Dutta';

if (fullName) {

var firstName = fullName.split(' ')[0];

console.log('firstName',firstName);

}

console.log(firstName);