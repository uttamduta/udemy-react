// Solution for chapter 46 for Counter example wiht lify cycle methods and localStorage
  

class Counter extends React.Component{

    constructor (props){
        super(props);
        this.handleAddOne    = this.handleAddOne.bind(this);
        this.handleMinusOne  = this.handleMinusOne.bind(this);
        this.handleReset     = this.handleReset.bind(this);
        this.state = {
            count: 0
        };
    }

    componentDidMount(){
        const stringCount = localStorage.getItem('mycount');
        const intCount    = parseInt(stringCount, 10);

        if (!isNaN(intCount)){
            console.log('Loading with value :',intCount);
            this.setState(()=> ({count : intCount }));
        }

    }
    componentDidUpdate(prevProps, prevState){
        console.log('componentDidUpdate!');
        if (prevState.count !== this.state.count){
            localStorage.setItem('mycount',this.state.count);
        }

    }

    handleAddOne() {
        this.setState((prevState)=> {

            return{
                count:prevState.count  + 1
            }
          } 
       )
    }

    handleMinusOne() {
        this.setState((prevState)=> {

            return{
                count:prevState.count  - 1
            }
          } 
       )
    }

    handleReset() { 
        this.setState(()=> {

            return{
                count:0
            }
          } 
       )
    }
    render() {
        return(
            <div>Hare Krishna Hare Rama
                <h1>Count: {this.state.count}</h1>
                <p>Chapter 46 Example</p>
                <button onClick={this.handleAddOne}>+1</button>
                <button onClick={this.handleMinusOne}>-1</button>
                <button onClick={this.handleReset}>Reset</button>
            </div>
        );
    }
}



ReactDOM.render(<Counter count={[-10]}/>, document.getElementById('app'));

