console.log('es6-arrow-function-2.js is running');

const add = (a, b) => {

    return a = b;
}

console.log(add(100,1000));


// ***** Non arrow function misses the context of this 
const user = {

    name    : 'Hare Krishna',
    age     : 57,
    cities  : ['Delhi','Mumbai','Virginia'],

    printPlacesLived() {      
        this.cities.forEach((cities)=> {
            console.log(this.name.split(' ')[0] + " LIVED in " + cities);
        });

    }
};

user.printPlacesLived();


// ** using same by an ArrowFunction 

const userArrow = {

    name    : 'Hare Krishna',
    age     : 50,
    cities  : ['Paharganj','C.R.Park','Goregaon','Falls Church','Centreville','Chantilly'],

    printPlacesLived : function() {

        this.cities.forEach((cities)=>{
            console.log(  this.name + " lived in " + cities);
        });

    }
};

userArrow.printPlacesLived();

// ** use of Map Method - Long Hand Implementaion 

const userArrowwithLongMap = {

    name    : 'Hare Krishna',
    age     : 50,
    cities  : ['Paharganj','C.R.Park','Goregaon','Falls Church','Centreville','Chantilly'],

    printPlacesLived : function() { 
        return this.cities.map((myCity) => {
                return this.name + ' has lived in ' + myCity + "!!";
        });
    }
};
console.log('---->>>> With Map Long Hand Code ');
console.log(userArrowwithLongMap.cities);
console.log(userArrowwithLongMap.printPlacesLived());

// ** use of Map Method - Short Hand Implemenataion 

const userArrowwithshortMap = {

    name    : 'Hare Krishna',
    age     : 50,
    cities  : ['Paharganj','C.R.Park','Goregaon','Falls Church','Centreville','Chantilly'],
    printPlacesLived : function() { 
        return this.cities.map((myCity) => this.name + ' has lived in ' + myCity + "!!");
    }
};
console.log('---->>>> With Map Short  Hand Code ');
console.log(userArrowwithshortMap.cities);
console.log(userArrowwithshortMap.printPlacesLived());

// ** Challege Aread - Multiplier 

const multiplier =  {

    numbers: [10, 20, 30],
    multiplyBy : 3,
    multiply() {
        return this.numbers.map((myNumber) => myNumber * this.multiplyBy);
    }
}
console.log('---->>>> Challenge Multiplier  ');
console.log(multiplier.numbers);
console.log(multiplier.multiply());
console.log('---->>>> Challenge Multiplier  - It Worked !!!');